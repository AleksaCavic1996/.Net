﻿
namespace Kolokvijum1deo_Aleksa_Cavic_s4_19
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreate = new System.Windows.Forms.Button();
            this.dgKupci = new System.Windows.Forms.DataGridView();
            this.dgFakture = new System.Windows.Forms.DataGridView();
            this.dgStavke = new System.Windows.Forms.DataGridView();
            this.btnXML = new System.Windows.Forms.Button();
            this.btnXMLS = new System.Windows.Forms.Button();
            this.txtNaziv = new System.Windows.Forms.TextBox();
            this.txtAdresa = new System.Windows.Forms.TextBox();
            this.lblNaziv = new System.Windows.Forms.Label();
            this.lblAdresa = new System.Windows.Forms.Label();
            this.btnDodajKupca = new System.Windows.Forms.Button();
            this.txtKupacID = new System.Windows.Forms.TextBox();
            this.txtFakturaID = new System.Windows.Forms.TextBox();
            this.lblKupacID = new System.Windows.Forms.Label();
            this.lblFakturaID = new System.Windows.Forms.Label();
            this.lblDatum = new System.Windows.Forms.Label();
            this.dateDatum = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFakturaIDStavke = new System.Windows.Forms.TextBox();
            this.txtNazivStavke = new System.Windows.Forms.TextBox();
            this.txtCena = new System.Windows.Forms.MaskedTextBox();
            this.btnDodajFakturu = new System.Windows.Forms.Button();
            this.btnDodajStavku = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgKupci)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgFakture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgStavke)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(12, 12);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(133, 47);
            this.btnCreate.TabIndex = 0;
            this.btnCreate.Text = "DS create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // dgKupci
            // 
            this.dgKupci.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgKupci.Location = new System.Drawing.Point(12, 109);
            this.dgKupci.Name = "dgKupci";
            this.dgKupci.Size = new System.Drawing.Size(245, 207);
            this.dgKupci.TabIndex = 1;
            // 
            // dgFakture
            // 
            this.dgFakture.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFakture.Location = new System.Drawing.Point(340, 109);
            this.dgFakture.Name = "dgFakture";
            this.dgFakture.Size = new System.Drawing.Size(244, 207);
            this.dgFakture.TabIndex = 2;
            // 
            // dgStavke
            // 
            this.dgStavke.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgStavke.Location = new System.Drawing.Point(653, 109);
            this.dgStavke.Name = "dgStavke";
            this.dgStavke.Size = new System.Drawing.Size(237, 207);
            this.dgStavke.TabIndex = 3;
            // 
            // btnXML
            // 
            this.btnXML.Location = new System.Drawing.Point(12, 549);
            this.btnXML.Name = "btnXML";
            this.btnXML.Size = new System.Drawing.Size(133, 57);
            this.btnXML.TabIndex = 4;
            this.btnXML.Text = "XML";
            this.btnXML.UseVisualStyleBackColor = true;
            this.btnXML.Click += new System.EventHandler(this.btnXML_Click);
            // 
            // btnXMLS
            // 
            this.btnXMLS.Location = new System.Drawing.Point(151, 549);
            this.btnXMLS.Name = "btnXMLS";
            this.btnXMLS.Size = new System.Drawing.Size(133, 57);
            this.btnXMLS.TabIndex = 5;
            this.btnXMLS.Text = "XMLSchema";
            this.btnXMLS.UseVisualStyleBackColor = true;
            this.btnXMLS.Click += new System.EventHandler(this.btnXMLS_Click);
            // 
            // txtNaziv
            // 
            this.txtNaziv.Location = new System.Drawing.Point(157, 348);
            this.txtNaziv.Name = "txtNaziv";
            this.txtNaziv.Size = new System.Drawing.Size(100, 20);
            this.txtNaziv.TabIndex = 6;
            // 
            // txtAdresa
            // 
            this.txtAdresa.Location = new System.Drawing.Point(157, 409);
            this.txtAdresa.Name = "txtAdresa";
            this.txtAdresa.Size = new System.Drawing.Size(100, 20);
            this.txtAdresa.TabIndex = 7;
            // 
            // lblNaziv
            // 
            this.lblNaziv.AutoSize = true;
            this.lblNaziv.Location = new System.Drawing.Point(12, 351);
            this.lblNaziv.Name = "lblNaziv";
            this.lblNaziv.Size = new System.Drawing.Size(67, 13);
            this.lblNaziv.TabIndex = 8;
            this.lblNaziv.Text = "Naziv kupca";
            // 
            // lblAdresa
            // 
            this.lblAdresa.AutoSize = true;
            this.lblAdresa.Location = new System.Drawing.Point(12, 412);
            this.lblAdresa.Name = "lblAdresa";
            this.lblAdresa.Size = new System.Drawing.Size(40, 13);
            this.lblAdresa.TabIndex = 9;
            this.lblAdresa.Text = "Adresa";
            // 
            // btnDodajKupca
            // 
            this.btnDodajKupca.Location = new System.Drawing.Point(157, 487);
            this.btnDodajKupca.Name = "btnDodajKupca";
            this.btnDodajKupca.Size = new System.Drawing.Size(100, 23);
            this.btnDodajKupca.TabIndex = 10;
            this.btnDodajKupca.Text = "Dodaj";
            this.btnDodajKupca.UseVisualStyleBackColor = true;
            this.btnDodajKupca.Click += new System.EventHandler(this.btnDodajKupca_Click);
            // 
            // txtKupacID
            // 
            this.txtKupacID.Location = new System.Drawing.Point(484, 344);
            this.txtKupacID.Name = "txtKupacID";
            this.txtKupacID.Size = new System.Drawing.Size(100, 20);
            this.txtKupacID.TabIndex = 11;
            // 
            // txtFakturaID
            // 
            this.txtFakturaID.Location = new System.Drawing.Point(484, 384);
            this.txtFakturaID.Name = "txtFakturaID";
            this.txtFakturaID.Size = new System.Drawing.Size(100, 20);
            this.txtFakturaID.TabIndex = 12;
            // 
            // lblKupacID
            // 
            this.lblKupacID.AutoSize = true;
            this.lblKupacID.Location = new System.Drawing.Point(347, 347);
            this.lblKupacID.Name = "lblKupacID";
            this.lblKupacID.Size = new System.Drawing.Size(49, 13);
            this.lblKupacID.TabIndex = 14;
            this.lblKupacID.Text = "KupacID";
            // 
            // lblFakturaID
            // 
            this.lblFakturaID.AutoSize = true;
            this.lblFakturaID.Location = new System.Drawing.Point(347, 387);
            this.lblFakturaID.Name = "lblFakturaID";
            this.lblFakturaID.Size = new System.Drawing.Size(54, 13);
            this.lblFakturaID.TabIndex = 15;
            this.lblFakturaID.Text = "FakturaID";
            // 
            // lblDatum
            // 
            this.lblDatum.AutoSize = true;
            this.lblDatum.Location = new System.Drawing.Point(347, 431);
            this.lblDatum.Name = "lblDatum";
            this.lblDatum.Size = new System.Drawing.Size(38, 13);
            this.lblDatum.TabIndex = 16;
            this.lblDatum.Text = "Datum";
            // 
            // dateDatum
            // 
            this.dateDatum.Location = new System.Drawing.Point(451, 424);
            this.dateDatum.Name = "dateDatum";
            this.dateDatum.Size = new System.Drawing.Size(133, 20);
            this.dateDatum.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(650, 351);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "FakturaID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(650, 387);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Naziv stavke";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(650, 431);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Cena stavke";
            // 
            // txtFakturaIDStavke
            // 
            this.txtFakturaIDStavke.Location = new System.Drawing.Point(790, 348);
            this.txtFakturaIDStavke.Name = "txtFakturaIDStavke";
            this.txtFakturaIDStavke.Size = new System.Drawing.Size(100, 20);
            this.txtFakturaIDStavke.TabIndex = 21;
            // 
            // txtNazivStavke
            // 
            this.txtNazivStavke.Location = new System.Drawing.Point(790, 387);
            this.txtNazivStavke.Name = "txtNazivStavke";
            this.txtNazivStavke.Size = new System.Drawing.Size(100, 20);
            this.txtNazivStavke.TabIndex = 22;
            // 
            // txtCena
            // 
            this.txtCena.Location = new System.Drawing.Point(790, 431);
            this.txtCena.Mask = "999.99";
            this.txtCena.Name = "txtCena";
            this.txtCena.Size = new System.Drawing.Size(100, 20);
            this.txtCena.TabIndex = 25;
            this.txtCena.ValidatingType = typeof(int);
            // 
            // btnDodajFakturu
            // 
            this.btnDodajFakturu.Location = new System.Drawing.Point(484, 487);
            this.btnDodajFakturu.Name = "btnDodajFakturu";
            this.btnDodajFakturu.Size = new System.Drawing.Size(100, 23);
            this.btnDodajFakturu.TabIndex = 26;
            this.btnDodajFakturu.Text = "Dodaj";
            this.btnDodajFakturu.UseVisualStyleBackColor = true;
            this.btnDodajFakturu.Click += new System.EventHandler(this.btnDodajFakturu_Click);
            // 
            // btnDodajStavku
            // 
            this.btnDodajStavku.Location = new System.Drawing.Point(790, 487);
            this.btnDodajStavku.Name = "btnDodajStavku";
            this.btnDodajStavku.Size = new System.Drawing.Size(100, 23);
            this.btnDodajStavku.TabIndex = 27;
            this.btnDodajStavku.Text = "Dodaj";
            this.btnDodajStavku.UseVisualStyleBackColor = true;
            this.btnDodajStavku.Click += new System.EventHandler(this.btnDodajStavku_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 646);
            this.Controls.Add(this.btnDodajStavku);
            this.Controls.Add(this.btnDodajFakturu);
            this.Controls.Add(this.txtCena);
            this.Controls.Add(this.txtNazivStavke);
            this.Controls.Add(this.txtFakturaIDStavke);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateDatum);
            this.Controls.Add(this.lblDatum);
            this.Controls.Add(this.lblFakturaID);
            this.Controls.Add(this.lblKupacID);
            this.Controls.Add(this.txtFakturaID);
            this.Controls.Add(this.txtKupacID);
            this.Controls.Add(this.btnDodajKupca);
            this.Controls.Add(this.lblAdresa);
            this.Controls.Add(this.lblNaziv);
            this.Controls.Add(this.txtAdresa);
            this.Controls.Add(this.txtNaziv);
            this.Controls.Add(this.btnXMLS);
            this.Controls.Add(this.btnXML);
            this.Controls.Add(this.dgStavke);
            this.Controls.Add(this.dgFakture);
            this.Controls.Add(this.dgKupci);
            this.Controls.Add(this.btnCreate);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgKupci)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgFakture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgStavke)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.DataGridView dgKupci;
        private System.Windows.Forms.DataGridView dgFakture;
        private System.Windows.Forms.DataGridView dgStavke;
        private System.Windows.Forms.Button btnXML;
        private System.Windows.Forms.Button btnXMLS;
        private System.Windows.Forms.TextBox txtNaziv;
        private System.Windows.Forms.TextBox txtAdresa;
        private System.Windows.Forms.Label lblNaziv;
        private System.Windows.Forms.Label lblAdresa;
        private System.Windows.Forms.Button btnDodajKupca;
        private System.Windows.Forms.TextBox txtKupacID;
        private System.Windows.Forms.TextBox txtFakturaID;
        private System.Windows.Forms.Label lblKupacID;
        private System.Windows.Forms.Label lblFakturaID;
        private System.Windows.Forms.Label lblDatum;
        private System.Windows.Forms.DateTimePicker dateDatum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFakturaIDStavke;
        private System.Windows.Forms.TextBox txtNazivStavke;
        private System.Windows.Forms.MaskedTextBox txtCena;
        private System.Windows.Forms.Button btnDodajFakturu;
        private System.Windows.Forms.Button btnDodajStavku;
    }
}

