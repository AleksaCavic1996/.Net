﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kolokvijum1deo_Aleksa_Cavic_s4_19
{
    public partial class Form1 : Form
    {
        DataTable kupci, fakture, faktureStavke;
        DataSet faktura;

        private void btnXML_Click(object sender, EventArgs e)
        {
            try
            {
                faktura.WriteXml(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Fakture.xml", XmlWriteMode.WriteSchema);
                MessageBox.Show("Snimljeno");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnXMLS_Click(object sender, EventArgs e)
        {
            try
            {
                faktura.WriteXmlSchema(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Fakture.xsd");
                MessageBox.Show("Snimljeno");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnDodajKupca_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow newProduct = kupci.NewRow();
                newProduct["NazivKupca"] = txtNaziv.Text;
                newProduct["Adresa"] =txtAdresa.Text;
                kupci.Rows.Add(newProduct);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDodajFakturu_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow newProduct = fakture.NewRow();
                newProduct["KupacID"] = txtKupacID.Text;
                newProduct["FakturaID"] = txtFakturaID.Text;
                newProduct["Datum"] = dateDatum.Text;
                fakture.Rows.Add(newProduct);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDodajStavku_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow newProduct = faktureStavke.NewRow();
                newProduct["FakturaID"] = txtFakturaIDStavke.Text;
                newProduct["NazivStavke"] = txtNazivStavke.Text;
                newProduct["CenaStavke"] = Convert.ToDouble(txtCena.Text);
                faktureStavke.Rows.Add(newProduct);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            kupci = new DataTable("Kupci");
            kupci.Columns.Add("KupacID", typeof(int));
            kupci.Columns.Add("NazivKupca", typeof(string));
            kupci.Columns.Add("Adresa", typeof(string));


            kupci.PrimaryKey = new DataColumn[] { kupci.Columns["KupacID"] };

            kupci.Columns["KupacID"].AutoIncrement = true;
            kupci.Columns["KupacID"].AutoIncrementSeed = 1;
            kupci.Columns["KupacID"].AutoIncrementStep = 1;
            kupci.Columns["KupacID"].AllowDBNull = false;

            kupci.Columns["NazivKupca"].AllowDBNull = false;
            kupci.Columns["NazivKupca"].Unique = true;
            kupci.Columns["NazivKupca"].MaxLength = 50;

            kupci.Columns["Adresa"].MaxLength = 200;
            kupci.Columns["Adresa"].AllowDBNull = true;

            fakture = new DataTable("Fakture");
            fakture.Columns.Add("FakturaID", typeof(int));
            fakture.Columns.Add("KupacID", typeof(int));
            fakture.Columns.Add("Datum", typeof(DateTime));  

            fakture.PrimaryKey = new DataColumn[] { fakture.Columns["FakturaID"] };

            fakture.Columns["FakturaID"].AutoIncrement = true;
            fakture.Columns["FakturaID"].AutoIncrementSeed = 1;
            fakture.Columns["FakturaID"].AutoIncrementStep = 1;
            fakture.Columns["FakturaID"].AllowDBNull = false;

            fakture.Columns["KupacID"].AllowDBNull = false;

            fakture.Columns["Datum"].DefaultValue = DateTime.Now;
            fakture.Columns["Datum"].AllowDBNull = false;

            faktureStavke = new DataTable("FakturaStavke");
            faktureStavke.Columns.Add("FakturaID", typeof(int));
            faktureStavke.Columns.Add("NazivStavke", typeof(string));
            faktureStavke.Columns.Add("CenaStavke", typeof(decimal));

            faktureStavke.PrimaryKey = new DataColumn[] { faktureStavke.Columns["FakturaID"], faktureStavke.Columns["NazivStavke"] };

            faktureStavke.Columns["FakturaID"].AllowDBNull = false;

            faktureStavke.Columns["NazivStavke"].MaxLength = 40;
            faktureStavke.Columns["NazivStavke"].AllowDBNull = false;

            faktureStavke.Columns["CenaStavke"].AllowDBNull = false;


            // pakujemo u DataSet
            faktura = new DataSet("Fakture");
            faktura.Tables.Add(kupci);
            faktura.Tables.Add(fakture);
            faktura.Tables.Add(faktureStavke);

            // pravimo relaciju
            DataRelation dataRelation1 = new DataRelation("RelacijeKupciFakture", kupci.Columns["KupacID"], fakture.Columns["KupacID"], true);
            DataRelation dataRelation2 = new DataRelation("RelacijeFaktureFakturaStavke", fakture.Columns["FakturaID"], faktureStavke.Columns["FakturaID"], true);

            faktura.Relations.Add(dataRelation1); 
            faktura.Relations.Add(dataRelation2);

            ForeignKeyConstraint fk1 = (ForeignKeyConstraint)fakture.Constraints["RelacijeKupciFakture"];
            fk1.DeleteRule = Rule.None;
            fk1.UpdateRule = Rule.None;

            ForeignKeyConstraint fk2 = (ForeignKeyConstraint)faktureStavke.Constraints["RelacijeFaktureFakturaStavke"];
            fk2.DeleteRule = Rule.None;
            fk2.UpdateRule = Rule.None;

            // dodajemo par slogova
            kupci.Rows.Add( 1, "Kupac 1");
            kupci.Rows.Add( 2, "Kupac 2");

            fakture.Rows.Add( 1, 1);
            fakture.Rows.Add( 2, 1);
            fakture.Rows.Add( 3, 2);
            fakture.Rows.Add( 4, 2);
            fakture.Rows.Add( 5, 2);

            faktureStavke.Rows.Add(1, "Caj", 140);
            faktureStavke.Rows.Add(3, "Zmaj", 1000);

            dgKupci.DataSource = kupci;
            dgFakture.DataSource = fakture;
            dgStavke.DataSource = faktureStavke;

        }
    }
}
