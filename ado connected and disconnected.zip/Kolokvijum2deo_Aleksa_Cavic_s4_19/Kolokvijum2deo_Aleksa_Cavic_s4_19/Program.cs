﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows;

namespace Kolokvijum2deo_Aleksa_Cavic_s4_19
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                SqlConnection Cn = new SqlConnection();

                string cnstr = System.Configuration.ConfigurationManager.ConnectionStrings["CnString"].ToString();
                Cn.ConnectionString = cnstr;
                Cn.Open();

                Console.WriteLine("Unesite ID kupca za brisanje: ");
                string unosID = Console.ReadLine();

                try
                {
                    int KupacID = int.Parse(unosID);
                    string query_string = "Sales.CustomerDelete";
                    SqlCommand komanda = new SqlCommand(query_string, Cn);

                    komanda.CommandType = CommandType.StoredProcedure;
                    komanda.Parameters.AddWithValue("@custid", KupacID.ToString());

                    var rezultat_za_vracanje = komanda.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
                    rezultat_za_vracanje.Direction = ParameterDirection.ReturnValue;

                    komanda.ExecuteNonQuery();
                    string rezultat = rezultat_za_vracanje.Value.ToString();

                    if (rezultat == "0")
                    {
                        Console.WriteLine("\nKupac je uspesno obrisan.");
                        Console.ReadLine();
                    }
                    else if (rezultat == "-1")
                    {
                        Console.WriteLine("\nKupac ima fakture i ne moze se obrisati.");
                        Console.ReadLine();
                    }
                    else if (rezultat == "-2")
                    {
                        Console.WriteLine("\nKupac sa tim ID-em ne postoji.");
                        Console.ReadLine();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
          
    }
}
