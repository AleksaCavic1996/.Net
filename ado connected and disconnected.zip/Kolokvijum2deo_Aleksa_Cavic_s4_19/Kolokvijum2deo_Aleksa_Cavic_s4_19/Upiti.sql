﻿USE TSQL;
GO

CREATE PROCEDURE Sales.CustomerDelete
	@custid int
AS

BEGIN TRY
	IF NOT EXISTS (SELECT custid FROM Sales.Customers
		WHERE custid = @custid)
	BEGIN
		RETURN -2; 
	END

	IF EXISTS (SELECT custid FROM Sales.Orders
		WHERE custid = @custid)
	BEGIN
		RETURN -1; 
	END


	DELETE FROM Sales.Customers WHERE custid = @custid

	RETURN 0; 
END TRY
BEGIN CATCH
	RETURN ERROR_NUMBER();
END CATCH
GO

